var bluecar=document.getElementById("bluecar");
var racecar=document.getElementById("racecar");
var result=document.getElementById("result");
const score=document.getElementById("score");
var game=document.getElementById("game");
var counter=0;
var sound=document.getElementById("sound");



bluecar.addEventListener("animationiteration" ,function(){
    var random=(Math.floor(Math.random() *4));
    if(random==0){
        random+=80;
    }
    else if(random==1){
        random+=139;
    }
    else if(random==2){
        random+=198;
    }
    else if(random==3){
        random+=257;
    }
    else if(random==4){
        random+=316;
    }
  
    bluecar.style.left=random+"px";
    counter++;
});

window.addEventListener("keydown", function(e){
    if(e.keyCode=="39"){
        var racecarLeft=parseInt(window.getComputedStyle(racecar).getPropertyValue("left"));
        // console.log(racecarLeft);
        if(racecarLeft<225){
            racecar.style.left=(racecarLeft+60)+"px";
        }
        sound.play();
    }
    if(e.keyCode=="37"){
        var racecarLeft=parseInt(window.getComputedStyle(racecar).getPropertyValue("left"));
        // console.log(racecarLeft);
        if(racecarLeft>75){
            racecar.style.left=(racecarLeft-60)+"px";
        }
        sound.play();
        
        

    }
   
});

setInterval(function GameOver(){
    var bluecarTop=parseInt(window.getComputedStyle(bluecar).getPropertyValue("top"));
    var bluecarLeft=parseInt(window.getComputedStyle(bluecar).getPropertyValue("left"));
    var racecarLeft=parseInt(window.getComputedStyle(racecar).getPropertyValue("left"));
    if((bluecarLeft===racecarLeft+5)&& (bluecarTop>250) &&(bluecarTop<450)){
        result.style.display="block";
        game.style.display="none";
        score.innerHTML="score: "+counter;
        counter=0;
    }
},10)